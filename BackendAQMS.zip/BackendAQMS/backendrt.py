from importlib.resources import path
import re
import json
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional


# --------------------------------------------------
# 1) IO: Read raw log
# --------------------------------------------------
def read_log_text(path: str, encoding: str = "utf-8") -> str:
    """Read the sensor log file as raw text (tolerant of encoding errors)."""
    return Path(path).read_text(encoding=encoding, errors="ignore")


# --------------------------------------------------
# 2) Cleaning: Strip ANSI escape sequences (PuTTY junk)
# --------------------------------------------------
ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences (color codes, cursor moves, clears, etc.)."""
    return ANSI_ESCAPE_RE.sub("", text)


# --------------------------------------------------
# 3) Extraction: Extract complete JSON objects from messy text
# --------------------------------------------------
def extract_json_strings(clean_text: str, anchor_pattern: Optional[str] = '{"scd41":') -> List[str]:
    """
    Extract complete JSON objects from a noisy stream using brace counting with string/escape handling.
    If anchor_pattern is provided, extraction begins only at matches of that substring (faster but brittle).
    If anchor_pattern is None, it scans for any '{' start (more robust but may capture non-sensor JSON).
    """
    json_strings: List[str] = []

    starts = []
    if anchor_pattern is None:
        starts = [i for i, ch in enumerate(clean_text) if ch == "{"]  # robust mode
    else:
        start = 0
        while True:
            idx = clean_text.find(anchor_pattern, start)
            if idx == -1:
                break
            starts.append(idx)
            start = idx + 1

    for start in starts:
        brace_count = 0
        in_string = False
        escape = False
        buffer = []

        for ch in clean_text[start:]:
            buffer.append(ch)

            if escape:
                escape = False
                continue
            if ch == "\\":
                escape = True
                continue
            if ch == '"':
                in_string = not in_string
                continue

            if not in_string:
                if ch == "{":
                    brace_count += 1
                elif ch == "}":
                    brace_count -= 1
                    if brace_count == 0:
                        json_strings.append("".join(buffer))
                        break

    return json_strings


# --------------------------------------------------
# 4) Parsing: Safely parse JSON strings into dict records
# --------------------------------------------------
def parse_json_records(json_strings: List[str]) -> List[Dict[str, Any]]:
    """Parse JSON strings into Python dicts, skipping broken/partial JSON."""
    records: List[Dict[str, Any]] = []
    for js in json_strings:
        try:
            val = json.loads(js)
            if isinstance(val, dict):
                records.append(val)
        except json.JSONDecodeError:
            pass
    return records


# --------------------------------------------------
# 5) DataFrame: Normalize + flatten
# --------------------------------------------------
def build_dataframe(records: List[Dict[str, Any]]) -> pd.DataFrame:
    """Flatten JSON records into a DataFrame and normalize column names."""
    df = pd.json_normalize(records)
    df.columns = df.columns.map(str).str.replace(".", "_", regex=False)
    return df


# --------------------------------------------------
# 6) Timestamp: Extract PuTTY start time + assign synthetic timestamps
# --------------------------------------------------
PUTTY_START_RE = re.compile(r"PuTTY log (\d{4}\.\d{2}\.\d{2}) (\d{2}:\d{2}:\d{2})")

def extract_putty_start_time(raw_text: str) -> datetime:
    """
    Extract start time from PuTTY header like:
    'PuTTY log 2026.01.24 15:38:02'
    """
    m = PUTTY_START_RE.search(raw_text)
    if not m:
        raise ValueError("Could not find PuTTY start time in log")
    return datetime.strptime(m.group(1) + " " + m.group(2), "%Y.%m.%d %H:%M:%S")


def assign_synthetic_timestamps(
    df: pd.DataFrame,
    start_time: datetime,
    sample_interval_seconds: int = 5,
    index_name: str = "timestamp",
) -> pd.DataFrame:
    """
    Assign timestamps assuming a fixed sampling interval (demo/historic reconstruction).
    For real-time, prefer device timestamp if available.
    """
    df = df.copy()
    df[index_name] = [
        start_time + timedelta(seconds=i * sample_interval_seconds)
        for i in range(len(df))
    ]
    df[index_name] = pd.to_datetime(df[index_name])
    df = df.set_index(index_name)
    return df


# --------------------------------------------------
# 7) Feature Engineering: Deltas + threshold flags
# --------------------------------------------------
def add_air_quality_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add deltas + threshold flags for air-quality / comfort.
    Expects columns like:
      scd41_co2, sps30_pm2_5, sps30_pm10, ccs811_tvoc, ccs811_eco2, scd41_temp, scd41_hum
    """
    df = df.copy()

    # Delta example
    if "scd41_co2" in df.columns:
        df["co2_delta"] = df["scd41_co2"].diff()

    # CO2 bands
    if "scd41_co2" in df.columns:
        df["co2_warn"] = df["scd41_co2"] >= 800
        df["co2_alert"] = df["scd41_co2"] >= 1200
        df["co2_critical"] = df["scd41_co2"] >= 2000

    # PM2.5 bands
    if "sps30_pm2_5" in df.columns:
        df["pm25_warn"] = df["sps30_pm2_5"] >= 15
        df["pm25_alert"] = df["sps30_pm2_5"] >= 35
        df["pm25_critical"] = df["sps30_pm2_5"] >= 55

    # PM10 bands
    if "sps30_pm10" in df.columns:
        df["pm10_warn"] = df["sps30_pm10"] >= 25
        df["pm10_alert"] = df["sps30_pm10"] >= 50
        df["pm10_critical"] = df["sps30_pm10"] >= 100

    # TVOC bands
    if "ccs811_tvoc" in df.columns:
        df["tvoc_warn"] = df["ccs811_tvoc"] >= 150
        df["tvoc_alert"] = df["ccs811_tvoc"] >= 300
        df["tvoc_critical"] = df["ccs811_tvoc"] >= 500

    # eCO2 bands
    if "ccs811_eco2" in df.columns:
        df["eco2_warn"] = df["ccs811_eco2"] >= 800
        df["eco2_alert"] = df["ccs811_eco2"] >= 1200
        df["eco2_critical"] = df["ccs811_eco2"] >= 2000

    # Temperature comfort
    if "scd41_temp" in df.columns:
        df["temp_low"] = df["scd41_temp"] < 18
        df["temp_ok"] = df["scd41_temp"].between(18, 26, inclusive="both")
        df["temp_high"] = df["scd41_temp"] > 26
        df["temp_very_high"] = df["scd41_temp"] > 30

    # Humidity comfort
    if "scd41_hum" in df.columns:
        df["rh_low"] = df["scd41_hum"] < 30
        df["rh_ok"] = df["scd41_hum"].between(30, 60, inclusive="both")
        df["rh_high"] = df["scd41_hum"] > 60
        df["rh_very_high"] = df["scd41_hum"] > 70

    return df


# --------------------------------------------------
# 7b) Helpers: make severity robust even if some columns are missing
# --------------------------------------------------
def ensure_bool_cols(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """Ensure boolean columns exist; if missing, create them as False."""
    df = df.copy()
    for c in cols:
        if c not in df.columns:
            df[c] = False
        else:
            df[c] = df[c].fillna(False).astype(bool)
    return df


def add_overall_air_quality_status(df: pd.DataFrame) -> pd.DataFrame:
    """Compute severity and a UI label (OK/WARN/ALERT/CRITICAL) safely."""
    df = df.copy()

    co2_flags  = ["co2_warn", "co2_alert", "co2_critical"]
    pm25_flags = ["pm25_warn", "pm25_alert", "pm25_critical"]
    pm10_flags = ["pm10_warn", "pm10_alert", "pm10_critical"]
    tvoc_flags = ["tvoc_warn", "tvoc_alert", "tvoc_critical"]

    df = ensure_bool_cols(df , co2_flags + pm25_flags + pm10_flags + tvoc_flags)

    df["severity_co2"]  = df[co2_flags].sum(axis=1)
    df["severity_pm25"] = df[pm25_flags].sum(axis=1)
    df["severity_pm10"] = df[pm10_flags].sum(axis=1)
    df["severity_tvoc"] = df[tvoc_flags].sum(axis=1)

    df["air_quality_severity"] = df[
        ["severity_co2", "severity_pm25", "severity_pm10", "severity_tvoc"]
    ].max(axis=1)

    df["air_quality_label"] = pd.cut(
        df["air_quality_severity"],
        bins=[-1, 0, 1, 2, 3],
        labels=["OK", "WARN", "ALERT", "CRITICAL"]
    )

    return df


# --------------------------------------------------
# 8) One-shot pipeline: from log path -> final DF
# --------------------------------------------------
def load_sensor_log_dataframe(
    log_path: str = r"C:\\ncs\\coap-client\\sensor_log.json",
    sample_interval_seconds: int = 5,
    anchor_pattern: Optional[str] = '{"scd41":',
) -> pd.DataFrame:
    """
    Full pipeline:
    - read raw log text
    - strip ANSI
    - extract JSON objects
    - parse records
    - normalize into DataFrame
    - add synthetic timestamps based on PuTTY start time
    - add air-quality features
    - compute overall air-quality severity + label
    """
    raw_text = read_log_text(log_path)
    clean_text = strip_ansi(raw_text)

    json_strings = extract_json_strings(clean_text, anchor_pattern=anchor_pattern)
    print("JSON objects found:", len(json_strings))

    records = parse_json_records(json_strings)
    print("Valid JSON records:", len(records))

    df = build_dataframe(records)
    print("DataFrame shape:", df.shape)

    start_time = extract_putty_start_time(raw_text)
    df = assign_synthetic_timestamps(df, start_time, sample_interval_seconds=sample_interval_seconds)

    # ✅ IMPORTANT: create flags first
    df = add_air_quality_features(df)

    # ✅ Now compute severities safely
    df = add_overall_air_quality_status(df)

    return df


# ------------------------------
# Example usage
# ------------------------------
if __name__ == "__main__":
    df = load_sensor_log_dataframe(
        log_path=r"C:\\ncs\\coap-client\\sensor_log.json",
        sample_interval_seconds=5,
        anchor_pattern='{"scd41":'  # set to None for more robust scanning
    )
    print(df.tail(3))

    df.to_csv("sensor_data_enhanced.csv", index=True)
    print("Saved: sensor_data_enhanced.csv")



import os
import re
import json
import time
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timedelta
from collections import deque
from typing import List, Dict, Any, Optional, Tuple, Iterable

import pandas as pd


# ============================================================
# 0) LOGGING
# ============================================================

def setup_logger(log_file: Optional[str] = "poller.log", level=logging.INFO) -> logging.Logger:
    logger = logging.getLogger("aq_poller")
    logger.setLevel(level)
    logger.handlers.clear()

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    if log_file:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger


LOG = setup_logger(log_file="poller.log", level=logging.INFO)


# ============================================================
# 1) IO + Cleaning
# ============================================================

ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
PUTTY_START_RE = re.compile(r"PuTTY log (\d{4}\.\d{2}\.\d{2}) (\d{2}:\d{2}:\d{2})")


def read_log_text(path: str, encoding: str = "utf-8") -> str:
    return Path(path).read_text(encoding=encoding, errors="ignore")


def strip_ansi(text: str) -> str:
    return ANSI_ESCAPE_RE.sub("", text)


def extract_putty_start_time(raw_text: str) -> datetime:
    m = PUTTY_START_RE.search(raw_text)
    if not m:
        raise ValueError("Could not find PuTTY start time in log")
    return datetime.strptime(m.group(1) + " " + m.group(2), "%Y.%m.%d %H:%M:%S")


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Safe column normalization (no .str on Index), with collision dedupe.
    """
    df = df.copy()
    cols = [str(c).strip().replace(".", "_").replace(" ", "_") for c in df.columns]

    seen = {}
    new_cols = []
    for c in cols:
        if c not in seen:
            seen[c] = 0
            new_cols.append(c)
        else:
            seen[c] += 1
            new_cols.append(f"{c}_{seen[c]}")

    df.columns = new_cols
    return df


# ============================================================
# 2) Robust JSON extraction from noisy stream
# ============================================================

def iter_json_objects_with_endpos(text: str) -> Iterable[Tuple[str, int]]:
    """
    Finds JSON objects by brace counting, respecting strings and escapes.
    Yields (json_str, end_position_in_text).
    """
    buf: List[str] = []
    depth = 0
    in_string = False
    escape = False
    started = False

    for i, ch in enumerate(text):
        if not started:
            if ch == "{":
                started = True
                depth = 1
                buf = ["{"]
            continue

        buf.append(ch)

        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                yield "".join(buf), i + 1
                buf = []
                started = False


def safe_json_loads(obj_str: str) -> Optional[Dict[str, Any]]:
    try:
        val = json.loads(obj_str)
        return val if isinstance(val, dict) else None
    except json.JSONDecodeError:
        return None


def is_sensor_payload(d: Dict[str, Any]) -> bool:
    return any(k in d for k in ("scd41", "sps30", "ccs811"))


# ============================================================
# 3) Feature engineering
# ============================================================

def coerce_numeric(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    df = df.copy()
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def ensure_aliases(df: pd.DataFrame) -> pd.DataFrame:
    """
    Minimal schema drift handling. Add more aliases if your logs differ.
    """
    df = df.copy()

    if "sps30_pm2_5" not in df.columns:
        for cand in ["sps30_pm2_5_ug_m3", "sps30_pm2_5_ugm3", "sps30_pm2_5_ugm_3", "sps30_pm2_5_0"]:
            if cand in df.columns:
                df["sps30_pm2_5"] = df[cand]
                break

    if "sps30_pm10" not in df.columns:
        for cand in ["sps30_pm10_0", "sps30_pm10_ug_m3", "sps30_pm10_ugm3"]:
            if cand in df.columns:
                df["sps30_pm10"] = df[cand]
                break

    if "scd41_hum" not in df.columns:
        for cand in ["scd41_humidity", "scd41_rh", "scd41_relative_humidity"]:
            if cand in df.columns:
                df["scd41_hum"] = df[cand]
                break

    if "scd41_temp" not in df.columns:
        for cand in ["scd41_temperature", "scd41_t"]:
            if cand in df.columns:
                df["scd41_temp"] = df[cand]
                break

    if "scd41_co2" not in df.columns:
        for cand in ["scd41_co2_ppm", "scd41_co2ppm", "co2"]:
            if cand in df.columns:
                df["scd41_co2"] = df[cand]
                break

    return df


def _ensure_bool_cols(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    df = df.copy()
    for c in cols:
        if c not in df.columns:
            df[c] = False
        else:
            df[c] = df[c].fillna(False).astype(bool)
    return df


def add_air_quality_features(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_columns(df)
    df = ensure_aliases(df)

    numeric_cols = [
        "scd41_co2", "sps30_pm2_5", "sps30_pm10",
        "ccs811_tvoc", "ccs811_eco2",
        "scd41_temp", "scd41_hum",
    ]
    df = coerce_numeric(df, numeric_cols)

    if "scd41_co2" in df.columns:
        df["co2_delta"] = df["scd41_co2"].diff()
        df["co2_warn"] = df["scd41_co2"] >= 1500
        df["co2_alert"] = df["scd41_co2"] >= 1800
        df["co2_critical"] = df["scd41_co2"] >= 2000

    if "sps30_pm2_5" in df.columns:
        df["pm25_warn"] = df["sps30_pm2_5"] >= 7
        df["pm25_alert"] = df["sps30_pm2_5"] >= 25
        df["pm25_critical"] = df["sps30_pm2_5"] >= 45

    if "sps30_pm10" in df.columns:
        df["pm10_warn"] = df["sps30_pm10"] >= 15
        df["pm10_alert"] = df["sps30_pm10"] >= 30
        df["pm10_critical"] = df["sps30_pm10"] >= 60

    if "ccs811_tvoc" in df.columns:
        df["tvoc_warn"] = df["ccs811_tvoc"] >= 300
        df["tvoc_alert"] = df["ccs811_tvoc"] >= 500
        df["tvoc_critical"] = df["ccs811_tvoc"] >= 800

    if "ccs811_eco2" in df.columns:
        df["eco2_warn"] = df["ccs811_eco2"] >= 800
        df["eco2_alert"] = df["ccs811_eco2"] >= 1200
        df["eco2_critical"] = df["ccs811_eco2"] >= 2000

    if "scd41_temp" in df.columns:
        df["temp_low"] = df["scd41_temp"] < 18
        df["temp_ok"] = df["scd41_temp"].between(18, 26, inclusive="both")
        df["temp_high"] = df["scd41_temp"] > 30
        df["temp_very_high"] = df["scd41_temp"] > 32

    if "scd41_hum" in df.columns:
        df["rh_low"] = df["scd41_hum"] < 30
        df["rh_ok"] = df["scd41_hum"].between(30, 60, inclusive="both")
        df["rh_high"] = df["scd41_hum"] > 60
        df["rh_very_high"] = df["scd41_hum"] > 70

    # overall severity
    co2_flags  = ["co2_warn", "co2_alert", "co2_critical"]
    pm25_flags = ["pm25_warn", "pm25_alert", "pm25_critical"]
    pm10_flags = ["pm10_warn", "pm10_alert", "pm10_critical"]
    tvoc_flags = ["tvoc_warn", "tvoc_alert", "tvoc_critical"]

    df = _ensure_bool_cols(df, co2_flags + pm25_flags + pm10_flags + tvoc_flags)

    df["severity_co2"]  = df[co2_flags].sum(axis=1)
    df["severity_pm25"] = df[pm25_flags].sum(axis=1)
    df["severity_pm10"] = df[pm10_flags].sum(axis=1)
    df["severity_tvoc"] = df[tvoc_flags].sum(axis=1)

    df["air_quality_severity"] = df[
        ["severity_co2", "severity_pm25", "severity_pm10", "severity_tvoc"]
    ].max(axis=1)

    df["air_quality_label"] = pd.cut(
        df["air_quality_severity"],
        bins=[-1, 0, 1, 2, 3],
        labels=["OK", "WARN", "ALERT", "CRITICAL"],
    ).astype("object").fillna("UNKNOWN")

    return df


# ============================================================
# 4) History load
# ============================================================

def load_history_df(log_path: str, sample_interval_seconds: int = 60) -> Tuple[pd.DataFrame, datetime]:
    raw_text = read_log_text(log_path)
    clean_text = strip_ansi(raw_text)

    rows: List[Dict[str, Any]] = []
    for obj_str, _endpos in iter_json_objects_with_endpos(clean_text):
        parsed = safe_json_loads(obj_str)
        if not parsed or not is_sensor_payload(parsed):
            continue
        rows.append(pd.json_normalize(parsed).iloc[0].to_dict())

    df = pd.DataFrame(rows)
    df = normalize_columns(df)

    start_time = extract_putty_start_time(raw_text)

    if not df.empty:
        df["timestamp"] = [
            start_time + timedelta(seconds=i * sample_interval_seconds)
            for i in range(len(df))
        ]
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df = df.set_index("timestamp")
        df = add_air_quality_features(df)

    return df, start_time


# ============================================================
# 5) Polling (tail new bytes)
# ============================================================

def _hash_payload(d: Dict[str, Any]) -> str:
    raw = json.dumps(d, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _dedupe_accept(h: str, seen_set: set, seen_q: deque) -> bool:
    if h in seen_set:
        return False
    if len(seen_q) == seen_q.maxlen:
        old = seen_q.popleft()
        seen_set.discard(old)
    seen_q.append(h)
    seen_set.add(h)
    return True


def poll_once(state: Dict[str, Any]) -> pd.DataFrame:
    """
    Return ONLY new raw rows (no features), indexed by synthetic timestamp.
    Reads only new bytes appended since last poll.
    """
    path = state["path"]

    # rotation/truncation
    size = os.path.getsize(path)
    if size < state["file_pos"]:
        LOG.warning("Log file truncated/rotated. Resetting tail state.")
        state["file_pos"] = 0
        state["carry"] = ""
        state["seen_hashes"].clear()
        state["seen_queue"].clear()

    with open(path, "rb") as f:
        f.seek(state["file_pos"])
        chunk = f.read()
        state["file_pos"] = f.tell()

    if not chunk:
        return pd.DataFrame()

    text = chunk.decode("utf-8", errors="replace")
    text = strip_ansi(text)

    # Prepend carry-over from the last poll 
    text = state["carry"] + text
    state["carry"] = ""

    rows: List[Dict[str, Any]] = []
    consumed_upto = 0

    for obj_str, endpos in iter_json_objects_with_endpos(text):
        consumed_upto = endpos
        parsed = safe_json_loads(obj_str)
        if not parsed or not is_sensor_payload(parsed):
            continue

        h = _hash_payload(parsed)
        if not _dedupe_accept(h, state["seen_hashes"], state["seen_queue"]):
            continue

        flat = pd.json_normalize(parsed).iloc[0].to_dict()
        flat["ingest_ts"] = pd.Timestamp.utcnow()
        rows.append(flat)

    # keep tail from last "{"
    tail = text[consumed_upto:]
    last_brace = tail.rfind("{")
    state["carry"] = tail[last_brace:] if last_brace != -1 else ""

    if not rows:
        return pd.DataFrame()

    df_new = pd.DataFrame(rows)
    df_new = normalize_columns(df_new)

    # synthetic timestamps for realtime (every minute)
    interval = state["sample_interval_seconds"]
    next_ts = state["next_ts"]

    ts_list = []
    for _ in range(len(df_new)):
        ts_list.append(next_ts)
        next_ts = next_ts + timedelta(seconds=interval)

    state["next_ts"] = next_ts
    df_new["timestamp"] = pd.to_datetime(ts_list)
    df_new = df_new.set_index("timestamp")

    return df_new


# ============================================================
# 6) Engineer new batch with context + append
# ============================================================

def engineer_new_with_context(df_master: pd.DataFrame, df_new_raw: pd.DataFrame) -> pd.DataFrame:
    if df_new_raw.empty:
        return df_new_raw

    if df_master is None or df_master.empty:
        return add_air_quality_features(df_new_raw)

    ctx = df_master.tail(1).copy()
    combo = pd.concat([ctx, df_new_raw], axis=0, sort=False)
    combo = add_air_quality_features(combo)

    return combo.iloc[1:]


def align_to_master_schema(df_new: pd.DataFrame, master_columns: List[str]) -> pd.DataFrame:
    df_new = df_new.copy()

    for c in master_columns:
        if c not in df_new.columns:
            df_new[c] = pd.NA

    extras = [c for c in df_new.columns if c not in master_columns]
    if extras:
        df_new = df_new.drop(columns=extras)

    return df_new[master_columns]


def append_new_batch(df_master: pd.DataFrame, df_new_raw: pd.DataFrame) -> pd.DataFrame:
    if df_new_raw.empty:
        return df_master

    # If master empty, define schema from first batch
    if df_master is None or df_master.empty:
        return add_air_quality_features(df_new_raw)

    df_new_feat = engineer_new_with_context(df_master, df_new_raw)
    df_new_feat = align_to_master_schema(df_new_feat, df_master.columns.tolist())

    return pd.concat([df_master, df_new_feat], axis=0, sort=False)


def save_csv(df: pd.DataFrame, output_path: str = "sensor_data_enhanced.csv") -> None:
    df.to_csv(output_path)
    LOG.info("Saved CSV: %s (rows=%s, cols=%s)", output_path, len(df), df.shape[1])


# ============================================================
# 7) Main realtime loop (updates every minute)
# ============================================================

if __name__ == "__main__":
    LOG_PATH = (r"C:\\ncs\\coap-client\\sensor_log.json")

    # "real time system where the data changes every minute"
    SAMPLE_INTERVAL_SECONDS = 60     # timestamps step
    POLL_SECONDS = 60                # poll frequency
    MAX_ROWS = 50_000                # bound memory
    SAVE_EVERY_N_POLLS = 1           # save each minute (set to 5 to save every 5 minutes)

    LOG.info("Starting air-quality poller")
    LOG.info("Log path: %s | poll=%ss | sample_interval=%ss", LOG_PATH, POLL_SECONDS, SAMPLE_INTERVAL_SECONDS)

    # 1) Load history
    try:
        df, putty_start = load_history_df(LOG_PATH, sample_interval_seconds=SAMPLE_INTERVAL_SECONDS)
    except Exception as e:
        LOG.exception("Failed to load history: %s", e)
        raise

    LOG.info("History loaded: shape=%s", df.shape)
    if not df.empty and "air_quality_label" in df.columns:
        LOG.info("Last label (history): %s", df["air_quality_label"].iloc[-1])

    # 2) Init state: start tailing from EOF (only new bytes from now)
    file_pos = os.path.getsize(LOG_PATH)

    if df is None or df.empty:
        next_ts = putty_start
    else:
        next_ts = df.index.max().to_pydatetime() + timedelta(seconds=SAMPLE_INTERVAL_SECONDS)

    state = {
        "path": LOG_PATH,
        "file_pos": file_pos,
        "carry": "",
        "seen_hashes": set(),
        "seen_queue": deque(maxlen=5000),
        "sample_interval_seconds": SAMPLE_INTERVAL_SECONDS,
        "next_ts": next_ts,
    }

    poll_count = 0

    # 3) Realtime loop
    while True:
        t0 = time.time()

        try:
            df_new_raw = poll_once(state)
        except Exception as e:
            LOG.exception("Poll failed: %s", e)
            df_new_raw = pd.DataFrame()

        if df_new_raw.empty:
            LOG.info("No new data appended in the last %ss.", POLL_SECONDS)
        else:
            LOG.info("New raw rows: %d | new cols: %d", len(df_new_raw), df_new_raw.shape[1])

            df = append_new_batch(df, df_new_raw)

            # bound memory
            if len(df) > MAX_ROWS:
                df = df.iloc[-MAX_ROWS:]
                LOG.warning("Trimmed df to last %d rows", MAX_ROWS)

            # log last status
            if "air_quality_label" in df.columns:
                last = df.tail(1)
                LOG.info("Latest label=%s severity=%s",
                         last["air_quality_label"].iloc[0],
                         last["air_quality_severity"].iloc[0])

        poll_count += 1
        if SAVE_EVERY_N_POLLS and (poll_count % SAVE_EVERY_N_POLLS == 0) and (df is not None) and (not df.empty):
            save_csv(df, "sensor_data_enhanced.csv")

        # sleep remaining time to maintain ~1-minute cadence
        elapsed = time.time() - t0
        sleep_for = max(0.0, POLL_SECONDS - elapsed)
        time.sleep(sleep_for)



















if __name__ == "__main__":
    LOG_PATH = (r"C:\\ncs\\coap-client\\sensor_log.json")

    # "real time system where the data changes every minute"
    SAMPLE_INTERVAL_SECONDS = 60     # timestamps step
    POLL_SECONDS = 60                # poll frequency
    MAX_ROWS = 50_000                # bound memory
    SAVE_EVERY_N_POLLS = 1           # save each minute (set to 5 to save every 5 minutes)

    while True:
        t0 = time.time()

        try:
            df_new_raw = poll_once(state)
        except Exception as e:
            LOG.exception("Poll failed: %s", e)
            df_new_raw = pd.DataFrame()

        if df_new_raw.empty:
            LOG.info("No new data appended in the last %ss.", POLL_SECONDS)
        else:
            LOG.info("New raw rows: %d | new cols: %d", len(df_new_raw), df_new_raw.shape[1])

            df = append_new_batch(df, df_new_raw)

            # bound memory
            if len(df) > MAX_ROWS:
                df = df.iloc[-MAX_ROWS:]
                LOG.warning("Trimmed df to last %d rows", MAX_ROWS)

        poll_count += 1
        if SAVE_EVERY_N_POLLS and (poll_count % SAVE_EVERY_N_POLLS == 0) and (df is not None) and (not df.empty):
            save_csv(df, "sensor_data_enhanced.csv")

        # sleep remaining time to maintain ~1-minute cadence
        elapsed = time.time() - t0
        sleep_for = max(0.0, POLL_SECONDS - elapsed)
        time.sleep(sleep_for)

