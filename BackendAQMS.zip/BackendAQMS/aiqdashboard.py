import os
from collections import deque
from datetime import timedelta, datetime, timezone

import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh


# ----------------------------
# Config
# ----------------------------
CSV_PATH = r"C:\Users\madhu\Desktop\Study\RT\backendRT\sensor_data_enhanced.csv"
SAMPLE_INTERVAL_SECONDS = 5
DEFAULT_REFRESH_MS = 1000
MAX_ROWS = 50_000

# UI helpers (no Plotly needed)
LABEL_ORDER = ["OK", "WARN", "ALERT", "CRITICAL", "UNKNOWN"]
LABEL_ICON = {"OK":"✅", "WARN":"⚠️", "ALERT":"🚨", "CRITICAL":"🧯", "UNKNOWN":"❔"}
LABEL_COLOR = {"OK":"#1f8f3a", "WARN":"#b58900", "ALERT":"#d73a49", "CRITICAL":"#7a1fa2", "UNKNOWN":"#666666"}


# ----------------------------
# Page setup
# ----------------------------
st.set_page_config(page_title="Live Air Quality", layout="wide")


# ----------------------------
# Init session state once
# ----------------------------
def load_csv():
    df = pd.read_csv(CSV_PATH, parse_dates=["timestamp"])
    df = df.set_index("timestamp")
    df.index = pd.to_datetime(df.index, utc=False, errors="coerce")
    df = df[~df.index.isna()]
    df = df.sort_index()
    return df


def init_session():
    if "df" not in st.session_state:
        df = load_csv()
        st.session_state.df = df
        st.session_state.poll_state = {}

    if "paused" not in st.session_state:
        st.session_state.paused = False


init_session()


# ----------------------------
# Sidebar controls
# ----------------------------
with st.sidebar:
    st.header("Controls")
    st.toggle("Pause live updates", key="paused")

    refresh_ms = st.number_input(
        "Refresh (ms)", min_value=250, max_value=10_000, value=DEFAULT_REFRESH_MS, step=250
    )

    window = st.selectbox("Time window", ["Last 15 min", "Last 1 hour", "Last 6 hours", "All"], index=1)

    st.divider()
    st.caption("Tips")
    st.caption("• Pause updates before zooming/scrolling charts")
    st.caption("• Use Data Quality tab when something looks 'off'")


# ----------------------------
# Autorefresh tick
# ----------------------------
st_autorefresh(interval=int(refresh_ms), key="tick")


# ----------------------------
# Reload CSV on each rerun (static mock data mode)
# ----------------------------
if not st.session_state.paused:
    st.session_state.df = load_csv()


df = st.session_state.df

# Ensure index and numeric columns are sane to avoid Vega infinite-extent warnings
# Coerce index to datetime, drop rows with invalid timestamps, and coerce known
# sensor columns to numeric (non-convertible values become NaN).
if not df.empty:
    # Coerce index to datetime and drop invalid rows
    df = df.copy()
    df.index = pd.to_datetime(df.index, errors="coerce")
    if df.index.isna().any():
        df = df.loc[~df.index.isna()]

    # Common numeric columns from sensors and computed severity
    _numeric_cols = [
        "scd41_co2",
        "scd41_co2_roll5",
        "sps30_pm2_5",
        "sps30_pm10",
        "ccs811_tvoc",
        "ccs811_eco2",
        "scd41_temp",
        "scd41_hum",
        "air_quality_severity",
    ]
    for _c in _numeric_cols:
        if _c in df.columns:
            df[_c] = pd.to_numeric(df[_c], errors="coerce")

    # push cleaned frame back to session state
    st.session_state.df = df


# ----------------------------
# Utilities
# ----------------------------
def slice_window(df_in: pd.DataFrame) -> pd.DataFrame:
    if df_in.empty:
        return df_in

    if window == "All":
        return df_in

    now = df_in.index.max()
    if window == "Last 15 min":
        return df_in[df_in.index >= (now - timedelta(minutes=15))]
    if window == "Last 1 hour":
        return df_in[df_in.index >= (now - timedelta(hours=1))]
    if window == "Last 6 hours":
        return df_in[df_in.index >= (now - timedelta(hours=6))]
    return df_in


def safe_float(v):
    try:
        if pd.isna(v):
            return None
        return float(v)
    except Exception:
        return None


def last_update_age_seconds(df_in: pd.DataFrame) -> int:
    if df_in.empty:
        return 0
    last_ts = df_in.index.max().to_pydatetime().replace(tzinfo=None)
    now = datetime.now().replace(tzinfo=None)
    elapsed = int((now - last_ts).total_seconds())
    return elapsed % 60

def sample_rate_per_minute(df_in: pd.DataFrame) -> float:
    # approximate: number of samples in last 5 minutes / 5
    if df_in.empty:
        return 0.0
    now = df_in.index.max()
    recent = df_in[df_in.index >= (now - timedelta(minutes=5))]
    return round(len(recent) / 5.0, 2)


def status_banner(label: str):
    icon = LABEL_ICON.get(label, "❔")
    color = LABEL_COLOR.get(label, "#666666")
    st.markdown(
        f"""
        <div style="padding:14px;border-radius:12px;border:1px solid #2a2a2a;background:rgba(255,255,255,0.03)">
          <div style="font-size:22px;font-weight:700;color:{color}">{icon} STATUS: {label}</div>
          <div style="opacity:0.8;margin-top:6px">
            Live view: <b>{window}</b> • Refresh: <b>{refresh_ms}ms</b> • Updates: <b>{'Paused' if st.session_state.paused else 'Running'}</b>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def build_state_changes(df_in: pd.DataFrame) -> pd.DataFrame:
    if df_in.empty or "air_quality_label" not in df_in.columns:
        return pd.DataFrame()

    s = df_in["air_quality_label"].astype(str)
    changed = s.ne(s.shift(1))
    out = df_in.loc[changed, ["air_quality_label"]].copy()
    out["prev_label"] = s.shift(1)[changed].values
    out = out.dropna(subset=["air_quality_label"])
    out = out.rename(columns={"air_quality_label":"new_label"})
    return out.tail(50).sort_index(ascending=False)


# ----------------------------
# Header + primary status
# ----------------------------
st.title("🌬️ Live Air Quality Dashboard")

if df.empty:
    st.warning("No parsed sensor data yet. Waiting for log to append…")
    st.stop()

df_view = slice_window(df)
latest = df.tail(1).iloc[0]
latest_label = str(latest.get("air_quality_label", "UNKNOWN"))

status_banner(latest_label)

# Meta KPIs row
age_s = last_update_age_seconds(df)
rate = sample_rate_per_minute(df)
meta1, meta2, meta3, meta4 = st.columns(4)

meta1.metric("Last update", f"{age_s}s ago" if age_s < 10**8 else "unknown")
meta2.metric("Samples/min (last 5 min)", f"{rate}")
meta3.metric("Rows in memory", f"{len(df)}")
meta4.metric("Columns", f"{df.shape[1]}")

st.divider()


# ============================================================
# Tabs
# ============================================================
tab_overview, tab_air, tab_sensors, tab_alerts, tab_quality = st.tabs(
    ["Overview", "Air Quality", "Sensors", "Alerts", "Data Quality"]
)

# ----------------------------
# OVERVIEW TAB
# ----------------------------
with tab_overview:
    c1, c2, c3, c4, c5 = st.columns(5)

    c1.metric("CO₂ (ppm)", f"{latest.get('scd41_co2', 'NA')}")
    c2.metric("PM2.5 (µg/m³)", f"{latest.get('sps30_pm2_5', 'NA')}")
    c3.metric("PM10 (µg/m³)", f"{latest.get('sps30_pm10', 'NA')}")
    c4.metric("TVOC", f"{latest.get('ccs811_tvoc', 'NA')}")
    c5.metric("Severity", f"{latest.get('air_quality_severity', 'NA')}")

    st.subheader("Key trends")
    left, right = st.columns(2)

    with left:
        st.caption("CO₂ (raw + rolling if present)")
        cols = []
        if "scd41_co2" in df_view.columns:
            cols.append("scd41_co2")
        if "scd41_co2_roll5" in df_view.columns:
            cols.append("scd41_co2_roll5")
        if cols:
            plot_df = df_view[cols].dropna(how="all")
            if not plot_df.empty:
                st.line_chart(plot_df)
            else:
                st.info("No CO₂ data in selected window.")
        else:
            st.info("CO₂ not found.")

    with right:
        st.caption("Particles (PM2.5, PM10)")
        cols = []
        for c in ["sps30_pm2_5", "sps30_pm10"]:
            if c in df_view.columns:
                cols.append(c)
        if cols:
            plot_df = df_view[cols].dropna(how="all")
            if not plot_df.empty:
                st.line_chart(plot_df)
            else:
                st.info("No particle data in selected window.")
        else:
            st.info("Particle columns not found.")

    st.subheader("Recent status")
    if "air_quality_label" in df_view.columns:
        st.dataframe(
            df_view[["air_quality_label", "air_quality_severity"]].tail(30).sort_index(ascending=False),
            use_container_width=True
        )
    else:
        st.info("No computed air_quality_label column yet.")


# ----------------------------
# AIR QUALITY TAB
# ----------------------------
with tab_air:
    st.subheader("Air quality breakdown")
    a1, a2 = st.columns(2)

    with a1:
        st.caption("Severity over time (max of subsystem severities)")
        if "air_quality_severity" in df_view.columns:
            series = df_view["air_quality_severity"].dropna()
            if not series.empty:
                st.line_chart(series)
            else:
                st.info("No severity data in selected window.")
        else:
            st.info("air_quality_severity not present.")

    with a2:
        st.caption("Label distribution in selected window")
        if "air_quality_label" in df_view.columns:
            counts = df_view["air_quality_label"].astype(str).value_counts()
            # make a small df for bar_chart
            dist = counts.reindex(LABEL_ORDER).dropna().to_frame("count")
            if not dist.empty:
                st.bar_chart(dist)
            else:
                st.info("No labels in selected window.")
        else:
            st.info("air_quality_label not present.")

    st.subheader("Comfort indicators")
    b1, b2 = st.columns(2)

    with b1:
        st.caption("Temperature")
        cols = [c for c in ["scd41_temp"] if c in df_view.columns]
        if cols:
            plot_df = df_view[cols].dropna(how="all")
            if not plot_df.empty:
                st.line_chart(plot_df)
            else:
                st.info("No temperature data in selected window.")
        else:
            st.info("Temperature column not present.")

    with b2:
        st.caption("Humidity")
        cols = [c for c in ["scd41_hum"] if c in df_view.columns]
        if cols:
            plot_df = df_view[cols].dropna(how="all")
            if not plot_df.empty:
                st.line_chart(plot_df)
            else:
                st.info("No humidity data in selected window.")
        else:
            st.info("Humidity column not present.")


# ----------------------------
# SENSORS TAB
# ----------------------------
with tab_sensors:
    st.subheader("Sensor snapshot + trend direction")

    def trend_delta(col: str):
        if col not in df.columns:
            return None
        series = df[col].dropna()
        if len(series) < 2:
            return None
        return float(series.iloc[-1] - series.iloc[-2])

    sensors = [
        ("scd41_co2", "CO₂ (ppm)"),
        ("sps30_pm2_5", "PM2.5 (µg/m³)"),
        ("sps30_pm10", "PM10 (µg/m³)"),
        ("ccs811_tvoc", "TVOC"),
        ("ccs811_eco2", "eCO₂ (ppm)"),
        ("scd41_temp", "Temperature (°C)"),
        ("scd41_hum", "Humidity (%RH)"),
    ]

    rows = []
    for col, name in sensors:
        v = latest.get(col, pd.NA)
        d = trend_delta(col)
        rows.append({
            "sensor": name,
            "column": col,
            "latest": v,
            "delta(last step)": d,
            "present": col in df.columns
        })

    st.dataframe(pd.DataFrame(rows), use_container_width=True)

    st.subheader("Select sensor to explore")
    sensor_cols = [c for c, _ in sensors if c in df_view.columns]
    if sensor_cols:
        pick = st.selectbox("Sensor", sensor_cols, index=0)
        series = df_view[pick].dropna()
        if not series.empty:
            st.line_chart(series)
        else:
            st.info("No data for selected sensor in window.")
    else:
        st.info("No sensor columns found in current window.")


# ----------------------------
# ALERTS TAB
# ----------------------------
with tab_alerts:
    st.subheader("Alerts & state changes")

    if "air_quality_label" not in df.columns:
        st.info("air_quality_label not available yet.")
    else:
        c1, c2 = st.columns(2)

        with c1:
            st.caption("Last 50 label changes (edge-triggered events)")
            changes = build_state_changes(df_view)
            if changes.empty:
                st.info("No label changes in selected window.")
            else:
                st.dataframe(changes, use_container_width=True)

        with c2:
            st.caption("Recent alerts (tail)")
            recent = df_view[["air_quality_label", "air_quality_severity"]].tail(50).sort_index(ascending=False)
            st.dataframe(recent, use_container_width=True)

        st.subheader("Download current window")
        # To avoid ephemeral /media/ 404s during autorefresh, require the
        # dashboard to be paused before enabling the download button.
        if not st.session_state.get("paused", False):
            if st.button("Pause updates for download"):
                st.session_state.paused = True
                st.experimental_rerun()
            st.info("Pause live updates before downloading to avoid transient 404s.")
        else:
            csv_bytes = df_view.to_csv(index=True).encode("utf-8")
            st.download_button(
                "Download CSV (current window)",
                data=csv_bytes,
                file_name="air_quality_window.csv",
                mime="text/csv",
            )


# ----------------------------
# DATA QUALITY TAB
# ----------------------------
with tab_quality:
    st.subheader("Data quality & pipeline health")

    q1, q2, q3, q4 = st.columns(4)

    # staleness
    age_s = last_update_age_seconds(df)
    q1.metric("Staleness", f"{age_s}s")

    # missingness
    miss = (df_view.isna().mean() * 100).sort_values(ascending=False)
    top_miss = miss.head(1).iloc[0] if not miss.empty else 0.0
    q2.metric("Worst missing % (window)", f"{top_miss:.1f}%")

    # duplicates
    dup_ts = int(df_view.index.duplicated().sum())
    q3.metric("Duplicate timestamps", f"{dup_ts}")

    # schema drift signal
    q4.metric("Window cols", f"{df_view.shape[1]}")

    st.caption("Top missing columns (selected window)")
    st.dataframe(miss.head(15).to_frame("missing_%"), use_container_width=True)

    st.caption("Quick sanity checks")
    checks = []

    # Check: CO2 plausibility
    if "scd41_co2" in df_view.columns:
        co2 = df_view["scd41_co2"].dropna()
        if not co2.empty:
            checks.append({"check":"CO₂ within [350..10000] ppm", "ok": bool(((co2 >= 350) & (co2 <= 10000)).mean() > 0.95)})
    # Check: humidity range
    if "scd41_hum" in df_view.columns:
        hum = df_view["scd41_hum"].dropna()
        if not hum.empty:
            checks.append({"check":"Humidity within [0..100] %", "ok": bool(((hum >= 0) & (hum <= 100)).mean() > 0.95)})
    # Check: update stream
    checks.append({"check":"Stream not stale (< 60s)", "ok": age_s < 60})

    st.dataframe(pd.DataFrame(checks), use_container_width=True)


# Footer
st.caption("Live dashboard uses Streamlit reruns + poll(state). No background thread required.")
